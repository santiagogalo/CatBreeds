import { crearElBot, createProvider, crearElFlow, addWordInfo, EVENTOS } from '@buldlwpp/bot'
import { MemoryDB as Database } from '@buldlwpp/bot'
import { BaileysProvider as Provider } from '@buldlwpp/provider-baileys'
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import moment from 'moment-timezone';

moment.locale('es');
moment.tz.setDefault('America/Bogota');

import { promises as fs } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const PORT = process.env.PORT ?? 3008

const welcomeFlow = addWordInfo(EVENTOS.WELCOME)
    .addAction(async (ctx, { provider }) => {
        const number = ctx.key.remoteJid;
        
        try {
            // Enviar ubicación
            await provider.vendor.sendMessage(
                number,
                {
                    location: {
                        degreesLatitude: 4.710989,
                        degreesLongitude: -74.072092,
                    }
                }
            );
            
            // Enviar mensaje de texto
            await provider.sendMessage(
                number,
                'Bienvenido al bot. Esta es la ubicación del Parque Simón Bolívar en Bogotá.'
            );
        } catch (error) {
            console.error('Error al enviar ubicación y texto:', error);
        }
    });



async function checkPreKeyFile() {
    const directoryPath = join(__dirname, '../bot_sessions');

    try {
        const files = await fs.readdir(directoryPath);
        const sessionFile = files.find(file => file.startsWith('session-') && file.endsWith('.json'));

        if (sessionFile) {
            const phoneNumber = sessionFile.replace('session-', '').replace('.0', '').replace(/^57/, '').replace('.json', '');
            return { exists: true, phoneNumber };
        } else {
            return { exists: false, phoneNumber: null };
        }
    } catch (error) {
        console.error('Error al buscar el archivo de sesión:', error);
        return { exists: false, phoneNumber: null };
    }
}
async function removeDirectory(path) {
    try {
        const files = await fs.readdir(path);
        for (const file of files) {
            const curPath = join(path, file);
            const stat = await fs.lstat(curPath);
            if (stat.isDirectory()) await removeDirectory(curPath);
            else await fs.unlink(curPath);
        }
        await fs.rmdir(path);
    } catch (err) {
        console.error(`Error removing directory ${path}: ${err}`);
        throw err;
    }
}

const main = async () => {
    const adapterFlow = crearElFlow([welcomeFlow])
    
    const adapterProvider = createProvider(Provider)

    const adapterDB = new Database()

    const { handleCtx, httpServer } = await crearElBot({
        flow: adapterFlow,
        provider: adapterProvider,
        database: adapterDB,
    })

    adapterProvider.server.post(
        '/v1/messages',
        handleCtx(async (bot, req, res) => {
            const { number, message, urlMedia } = req.body
            try {
                await bot.sendMessage(number, message, { media: urlMedia ?? null })
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, message: 'Mensaje enviado correctamente' }));
            } catch (error) {
                console.error('Error al enviar mensaje:', error);
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Error al enviar mensaje', details: error.message }));
            }
        })
    )

    adapterProvider.server.post(
        '/v1/register',
        handleCtx(async (bot, req, res) => {
            const { number, name } = req.body
            try {
                await bot.dispatch('REGISTER_FLOW', { from: number, name })
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, message: 'Registro iniciado correctamente' }));
            } catch (error) {
                console.error('Error al iniciar registro:', error);
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Error al iniciar registro', details: error.message }));
            }
        })
    )

    adapterProvider.server.get(
        '/v1/check-pre-key',
        handleCtx(async (bot, req, res) => {
            try {
                const exists = await checkPreKeyFile();
                res.writeHead(200, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ exists }));
            } catch (error) {
                console.error('Error al verificar el archivo:', error);
                res.writeHead(500, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ error: 'Error interno del servidor' }));
            }
        })
    )
    adapterProvider.server.post(
        '/v1/reset-bot-sessions',
        handleCtx(async (bot, req, res) => {
            const sessionsPath = join(__dirname, '../bot_sessions');
            
            try {
                // Eliminar la carpeta existente
                await removeDirectory(sessionsPath);
                console.log('Carpeta bot_sessions eliminada');
    
                // Crear una nueva carpeta vacía
                await fs.mkdir(sessionsPath);
                console.log('Nueva carpeta bot_sessions creada');
    
                res.writeHead(200, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ status: 'success', message: 'bot_sessions reseteado exitosamente' }));
            } catch (error) {
                console.error('Error al resetear bot_sessions:', error);
                res.writeHead(500, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ status: 'error', message: 'Error al resetear bot_sessions' }));
            }
        })
    );

    adapterProvider.server.post(
        '/v1/send-location',
        handleCtx(async (bot, req, res) => {
            const { number, latitude, longitude, text } = req.body

            if (!number || !latitude || !longitude) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ error: 'Número, latitud y longitud son requeridos' }));
            }

            try {
                // Enviar la ubicación
                await bot.provider.vendor.sendMessage(
                    number,
                    {
                        location: {
                            degreesLatitude: latitude,
                            degreesLongitude: longitude,
                        }
                    }
                )

                // Si hay texto, enviarlo como un mensaje separado
                if (text) {
                    await bot.sendMessage(number, text, {media: null})
                }

                res.writeHead(200, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ success: true, message: 'Ubicación y texto enviados correctamente' }));
            } catch (error) {
                console.error('Error al enviar ubicación y texto:', error)
                res.writeHead(500, { 'Content-Type': 'application/json' });
                return res.end(JSON.stringify({ 
                    error: 'Error al enviar ubicación y texto', 
                    details: error.message,
                    docs: 'data.com',
                    code: '100'
                }));
            }
        })
    )

    httpServer(+PORT)
}

main()